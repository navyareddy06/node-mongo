var express = require('express');
var app = express();
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost/CustomerDB';

MongoClient.connect(url, function(err, db) {

    db.collection('Customer').insertOne({
        Name: "Navya Reddy",
        EmailId: "navyakoppula@gmail.com"
    });
});
